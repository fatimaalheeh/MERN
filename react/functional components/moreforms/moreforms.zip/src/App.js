// import './App.css';
import UserForm from './components/SignUp';

function App() { 

  return (
    <div className="App">
      <UserForm />
    </div>
  );
}

export default App;
